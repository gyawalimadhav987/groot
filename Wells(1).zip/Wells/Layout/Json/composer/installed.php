<?php return array (
  'root' => 
  array (
    'pretty_version' => '1.0.0+no-version-set',
    'version' => '1.0.0.0',
    'aliases' => 
    array (
    ),
    'reference' => NULL,
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => '1.0.0+no-version-set',
      'version' => '1.0.0.0',
      'aliases' => 
      array (
      ),
      'reference' => NULL,
    ),
    'jaybizzle/crawler-detect' => 
    array (
      'pretty_version' => 'v1.2.105',
      'version' => '1.2.105.0',
      'aliases' => 
      array (
      ),
      'reference' => '719c1ed49224857800c3dc40838b6b761d046105',
    ),
  ),
);
